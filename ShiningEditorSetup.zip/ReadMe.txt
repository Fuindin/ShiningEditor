ShiningEditor

Included are the neccessary files for installing ShiningEditor, a save state editor that currently supports Shining in the Darkness. Eventually 
I would like it to support Shining Force and Shining Force 2 as well.

This application has been tested and runs successfully in Windows 10. It allows editing of save state files with the (.gso and .gsx) extensions
created from the Fusion364 Genesis/Mega Drive emulator.

Files included:

ShiningEditor.msi
setup.exe

You may install the application by double-clicking the ShiningEditor.msi file or double-clicking the setup.exe file.